//*****************************************************************************
//
// project0.c - Example to demonstrate minimal TivaWare setup
//
// Copyright (c) 2012-2016 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
// 
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
// 
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
// 
// This is part of revision 2.1.3.156 of the EK-TM4C123GXL Firmware Package.
//
//*****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"

//*****************************************************************************
//
// Define pin to LED color mapping.
//
//*****************************************************************************

//*****************************************************************************
//
//! \addtogroup example_list
//! <h1>Project Zero (project0)</h1>
//!
//! This example demonstrates the use of TivaWare to setup the clocks and
//! toggle GPIO pins to make the LED's blink. This is a good place to start
//! understanding your launchpad and the tools that can be used to program it.
//
//*****************************************************************************

#define RED_LED   GPIO_PIN_1
#define BLUE_LED  GPIO_PIN_2
#define GREEN_LED GPIO_PIN_3
#define OUT_TOUCH GPIO_PIN_2
#define IN_TOUCH  GPIO_PIN_3

//*****************************************************************************
//
// The error routine that is called if the driver library encounters an error.
//
//*****************************************************************************
#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif

//*****************************************************************************
//
// Main 'C' Language entry point.  Toggle an LED using TivaWare.
//
//*****************************************************************************
int
main(void)
{
    //
    // Vars we'll need
    //
    int32_t capCount = 0;
    int32_t lastCount = 0;
    int32_t countAvg = 0;
    int8_t avgIndex = 0;
    int32_t countAvgArray[14] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    char pinSense = 0;

    //
    // Setup the system clock to run at 50 Mhz from PLL with crystal reference
    //
    SysCtlClockSet(SYSCTL_SYSDIV_4|SYSCTL_USE_PLL|SYSCTL_XTAL_16MHZ|
                    SYSCTL_OSC_MAIN);

    //
    // Enable and wait for the port to be ready for access
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF) & !SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA))
    {
    }
    
    //
    // Configure the GPIO port for the LED operation.
    //
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, RED_LED|BLUE_LED|GREEN_LED);
    GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, OUT_TOUCH);
    GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, IN_TOUCH);

    //
    // Loop Forever
    //
    while(1)
    {
        // Reset counter
        capCount = 0;

        // Set the output sensor pin high and make the LED red for the test
        //GPIOPinWrite(GPIO_PORTF_BASE, RED_LED|BLUE_LED|GREEN_LED, RED_LED);
        GPIOPinWrite(GPIO_PORTA_BASE, OUT_TOUCH, OUT_TOUCH);

        // Wait for the sensor pin to get the memo
        while(!GPIOPinRead(GPIO_PORTA_BASE, IN_TOUCH)) {
            capCount++;
        }

        // Assign the lastCount
        lastCount = capCount;

        // Add last count to the avgArray and find new average
        countAvgArray[avgIndex] = lastCount;

        // Find the average of the counts
        int8_t i = 0;
        int32_t sumAvgArray = 0;
        for (i = 0; i < 14; i++) {
            sumAvgArray += countAvgArray[i];
        };
        countAvg = sumAvgArray / 14;

        // Inc the avgIndex variable
        if (avgIndex>=13) {
            avgIndex = 0;
        }
        else {
            avgIndex++;
        }

        // Assign pinSense
        pinSense = (countAvg<=40);

        // Set LED output based on touch input
        // GPIOPinWrite(GPIO_PORTF_BASE, RED_LED|BLUE_LED|GREEN_LED, BLUE_LED);
        if (pinSense) {
            GPIOPinWrite(GPIO_PORTF_BASE, RED_LED|BLUE_LED|GREEN_LED, RED_LED|BLUE_LED);
        }
        else {
            GPIOPinWrite(GPIO_PORTF_BASE, RED_LED|BLUE_LED|GREEN_LED, 0x0);
        }
        GPIOPinWrite(GPIO_PORTA_BASE, OUT_TOUCH, 0x0);

        // Drop the output and wait for it to go down again
        SysCtlDelay(100000);
    }
}
