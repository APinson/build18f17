//deal with later:
//board init functions may claim pins that step on other pieces of the project
//sanity check clock speed

/*
 * Copyright (c) 2015, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *     its contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== spiloopback.c ========
 */
/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

/* TI-RTOS Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>

/* Example/Board Header files */
#include "Board.h"

#define TASKSTACKSIZE     768

/* Allocate buffers in .dma section of memory for concerto devices */
#ifdef MWARE
#pragma DATA_SECTION(masterRxBuffer, ".dma");
#pragma DATA_SECTION(masterTxBuffer, ".dma");
#endif

Task_Struct task0Struct, task1Struct;
Char task0Stack[TASKSTACKSIZE], task1Stack[TASKSTACKSIZE];

Void faderMove(char motorID, char moveDir)
{
    GPIO_write(Board_Fader1Stdby, 1);

    if (moveDir)
    {
        GPIO_write(Board_Fader1AIN1, 0);
        GPIO_write(Board_Fader1AIN2, 1);
    }
    else
    {
        GPIO_write(Board_Fader1AIN1, 1);
        GPIO_write(Board_Fader1AIN2, 0);
    }
}

Void faderStop()
{
    GPIO_write(Board_Fader1Stdby, 0);
}

Void faderDataTaskFxn (UArg arg0, UArg arg1)
{
    System_printf("Starting faderDataTaskFxn\n");
    System_flush();

    while(1)
    {
        faderMove(0,1);
        System_printf("Fader 1 is at: %d\n", GPIO_read(Board_Fader1In));
        System_flush();
        __delay_cycles(70000000); //1s,ish
        faderStop();
        System_printf("Fader 1 is at: %d\n", GPIO_read(Board_Fader1In));
        System_flush();
        __delay_cycles(70000000); //1s,ish
        faderMove(0,0);
        System_printf("Fader 1 is at: %d\n", GPIO_read(Board_Fader1In));
        System_flush();
        __delay_cycles(70000000); //1s,ish
        faderStop();
        System_printf("Fader 1 is at: %d\n", GPIO_read(Board_Fader1In));
        System_flush();
        __delay_cycles(70000000); //1s,ish
    }


}

Void screenTaskFxn (UArg arg0, UArg arg1)
{

    SPI_Handle masterSpi;
    SPI_Params masterSpiParams;
    UShort transmitBuffer[1];
    UShort receiveBuffer[1];
    bool transferOK;
  //  unsigned int cmd[1];

    /* Initialize SPI handle as default master */
    SPI_Params_init(&masterSpiParams);
    masterSpiParams.dataSize = 9;
    masterSpi = SPI_open(Board_SPI0, &masterSpiParams);
    if (masterSpi == NULL) {
        System_abort("Error initializing SPI\n");
    }
    else {
        System_printf("SPI initialized\n");
    }


    /* Initialize master SPI transaction structure */

    SPI_Transaction masterTransaction;
    masterTransaction.count = 1;
    masterTransaction.txBuf = transmitBuffer;
    masterTransaction.rxBuf = receiveBuffer;

    /* Initiate SPI transfer */
    //__delay_cycles(70000); //1ms,ish

    //example init from datasheet:
    transmitBuffer[0]=0x0fd; transferOK = SPI_transfer(masterSpi, &masterTransaction); //unlock cmds
/*    transmitBuffer[0]=0x112; transferOK = SPI_transfer(masterSpi, &masterTransaction); //turn it off

    transmitBuffer[0]=0x0ae; transferOK = SPI_transfer(masterSpi, &masterTransaction); //maybe

    transmitBuffer[0]=0x015; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x11c; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x15b; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x075; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x100; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x13f; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0bc; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x191; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0ca; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x13f; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0a2; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x100; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0a1; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x100; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0a0; transferOK = SPI_transfer(masterSpi, &masterTransaction);//remap: no idea
    transmitBuffer[0]=0x112; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x111; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0b5; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x100; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0ab; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x101; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0b4; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x1a0; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x1fd; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0c1; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x195; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0c7; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x1ef; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0b9; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0b1; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x1e2; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0d1; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x120; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x120; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0bb; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x11f; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0b6; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x108; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x1cd; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0be; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x107; transferOK = SPI_transfer(masterSpi, &masterTransaction);
*/
    transmitBuffer[0]=0x0a6; transferOK = SPI_transfer(masterSpi, &masterTransaction); //normal display, i think

    transmitBuffer[0]=0x0af; transferOK = SPI_transfer(masterSpi, &masterTransaction); //turn back on

    transmitBuffer[0]=0x0a5; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    __delay_cycles(70000000); //1s,ish
    transmitBuffer[0]=0x0a4; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    __delay_cycles(70000000); //1s,ish

    transmitBuffer[0]=0x0a5; transferOK = SPI_transfer(masterSpi, &masterTransaction);

//    if(transferOK) {
        /* Print contents of master receive buffer */
//        System_printf("Master: %s\n", masterRxBuffer);
//    }
//    else {
//        System_printf("Unsuccessful master SPI transfer");
//    }


//    System_printf("transfer 2: ");
 //   System_flush();

    /* Deinitialize SPI */
    SPI_close(masterSpi);

    System_printf("Done\n");

    System_flush();
}
/*
 *  ======== main ========
 */
int main(void)
{
    /* Construct BIOS objects */
    Task_Params taskParams;

    /* Shared vars */
    static char touchFader[5];
    static uint8_t dmxData[512];

    /* Call board init functions. */
    Board_initGeneral();
    Board_initGPIO();
    Board_initSPI();

    /* Construct master/slave Task threads */
    Task_Params_init(&taskParams);
    taskParams.priority = 2;
    taskParams.stackSize = TASKSTACKSIZE;
    taskParams.stack = &task0Stack;
    Task_construct(&task0Struct, (Task_FuncPtr)screenTaskFxn, &taskParams, NULL);

    // More important
    taskParams.stack = &task1Stack;
    taskParams.priority = 1;
    Task_construct(&task1Struct, (Task_FuncPtr)faderDataTaskFxn, &taskParams, NULL);

    /* Turn on user LED */
    GPIO_write(Board_LED2, Board_LED_ON); //0 is blue, 1 is green

    System_printf("here goes nothin!\n");
    /* SysMin will only print to the console when you call flush or exit */
    System_flush();

    /* Start BIOS */
    BIOS_start();

    return (0);
}
