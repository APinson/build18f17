//deal with later:
//board init functions may claim pins that step on other pieces of the project
//sanity check clock speed

/*
 * Copyright (c) 2015, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *     its contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== spiloopback.c ========
 */
/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

/* TI-RTOS Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>

/* Example/Board Header files */
#include "Board.h"

// Stuff we need for the ADC
#include <stdint.h>
#include "inc/hw_memmap.h"
#include "driverlib/adc.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"

#define TASKSTACKSIZE     768

/* Allocate buffers in .dma section of memory for concerto devices */
#ifdef MWARE
#pragma DATA_SECTION(masterRxBuffer, ".dma");
#pragma DATA_SECTION(masterTxBuffer, ".dma");
#endif

// Task stuff
Task_Struct task0Struct, task1Struct;
Char task0Stack[TASKSTACKSIZE], task1Stack[TASKSTACKSIZE];

// Shared Vars
char touchFader[5];
uint8_t dmxData[512];
uint32_t ADC0vals[5];

// Pooled Vars
EK_TM4C123GXL_GPIOName motorStdby[51] = {Board_Fader1Stdby,
                                        Board_Fader2Stdby,
                                        Board_Fader3Stdby,
                                        Board_Fader4Stdby,
                                        Board_Fader5Stdby
};

EK_TM4C123GXL_GPIOName motorAIN1[5] = {Board_Fader1AIN1,
                                       Board_Fader2AIN1,
                                       Board_Fader3AIN1,
                                       Board_Fader4AIN1,
                                       Board_Fader5AIN1
};

EK_TM4C123GXL_GPIOName motorAIN2[5] = {Board_Fader1AIN2,
                                       Board_Fader2AIN2,
                                       Board_Fader3AIN2,
                                       Board_Fader4AIN2,
                                       Board_Fader5AIN2
};

EK_TM4C123GXL_GPIOName faderPosIn[5] = {Board_Fader1In,
                                        Board_Fader2In,
                                        Board_Fader3In,
                                        Board_Fader4In,
                                        Board_Fader5In
};

EK_TM4C123GXL_GPIOName faderTouchIn[5] = {Board_Fader1_TouchIn,
                                          Board_Fader2_TouchIn,
                                          Board_Fader3_TouchIn,
                                          Board_Fader4_TouchIn,
                                          Board_Fader5_TouchIn
};

EK_TM4C123GXL_GPIOName faderTouchOut[5] = {Board_Fader1_TouchOut,
                                           Board_Fader2_TouchOut,
                                           Board_Fader3_TouchOut,
                                           Board_Fader4_TouchOut,
                                           Board_Fader5_TouchOut
};

Void Board_initADC()
{
    // Enable periphs and pins
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
    GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);
    GPIOPinTypeADC(GPIO_PORTD_BASE, GPIO_PIN_3);

    // Create sampling sequence
    ADCSequenceDisable(ADC0_BASE, 0);
    ADCSequenceConfigure(ADC0_BASE, 0, ADC_TRIGGER_PROCESSOR, 0);
    ADCSequenceStepConfigure(ADC0_BASE, 0, 0, ADC_CTL_CH0);  // PE3, Ain0
    ADCSequenceStepConfigure(ADC0_BASE, 0, 1, ADC_CTL_CH1);  // PE2, Ain1
    ADCSequenceStepConfigure(ADC0_BASE, 0, 2, ADC_CTL_CH2);  // PE1, Ain2
    ADCSequenceStepConfigure(ADC0_BASE, 0, 3, ADC_CTL_CH3);  // PE0, Ain3
    ADCSequenceStepConfigure(ADC0_BASE, 0, 4, ADC_CTL_CH4 | ADC_CTL_IE | ADC_CTL_END); // PD3, Ain4
    ADCSequenceEnable(ADC0_BASE, 0);
    ADCIntClear(ADC0_BASE, 0);
}

Void faderMove(char motorID, char moveDir)
{
    GPIO_write(motorStdby[motorID], 1);

    if (moveDir)
    {
        GPIO_write(motorAIN1[motorID], 0);
        GPIO_write(motorAIN2[motorID], 1);
    }
    else
    {
        GPIO_write(motorAIN1[motorID], 1);
        GPIO_write(motorAIN2[motorID], 0);
    }
}

Void faderStop(char motorID)
{
    GPIO_write(motorStdby[motorID], 0);
}

Void getADCData()
{
    ADCProcessorTrigger(ADC0_BASE, 0);
    while(!ADCIntStatus(ADC0_BASE, 0, false))
    {
    }
    ADCIntClear(ADC0_BASE, 0);
    ADCSequenceDataGet(ADC0_BASE, 0, ADC0vals);
}

Void faderDataTaskFxn (UArg arg0, UArg arg1)
{
    System_printf("Starting faderDataTaskFxn\n");
    System_flush();

    while(1)
    {/*
        faderMove(0,1);
        getADCData();
        System_printf("%d, %d, %d, %d, %d\n", ADC0vals[0], ADC0vals[1], ADC0vals[2], ADC0vals[3], ADC0vals[4]);
        System_flush();
        __delay_cycles(70000000); //1s,ish

        faderStop(0);
        getADCData();
        System_printf("%d, %d, %d, %d, %d\n", ADC0vals[0], ADC0vals[1], ADC0vals[2], ADC0vals[3], ADC0vals[4]);
        System_flush();
        __delay_cycles(70000000); //1s,ish

        faderMove(0,0);
        getADCData();
        System_printf("%d, %d, %d, %d, %d\n", ADC0vals[0], ADC0vals[1], ADC0vals[2], ADC0vals[3], ADC0vals[4]);
        System_flush();
        __delay_cycles(70000000); //1s,ish

        faderStop(0);
        getADCData();
        System_printf("%d, %d, %d, %d, %d\n", ADC0vals[0], ADC0vals[1], ADC0vals[2], ADC0vals[3], ADC0vals[4]);
        System_flush();
        __delay_cycles(70000000); //1s,ish
*/
        getADCData();
        if (ADC0vals[0]<1000)
        {
            faderMove(0,1);
        }
        else if (ADC0vals[0]>1100)
        {
            faderMove(0,0);
        }
        else
        {
            faderStop(0);
        }
    }


}

Void screenTaskFxn (UArg arg0, UArg arg1)
{

    SPI_Handle masterSpi;
    SPI_Params masterSpiParams;
    UShort transmitBuffer[1];
    UShort receiveBuffer[1];
    bool transferOK;
  //  unsigned int cmd[1];

    /* Initialize SPI handle as default master */
    SPI_Params_init(&masterSpiParams);
    masterSpiParams.dataSize = 9;
    masterSpi = SPI_open(Board_SPI0, &masterSpiParams);
    if (masterSpi == NULL) {
        System_abort("Error initializing SPI\n");
    }
    else {
        System_printf("SPI initialized\n");
    }


    /* Initialize master SPI transaction structure */

    SPI_Transaction masterTransaction;
    masterTransaction.count = 1;
    masterTransaction.txBuf = transmitBuffer;
    masterTransaction.rxBuf = receiveBuffer;

    /* Initiate SPI transfer */
    //__delay_cycles(70000); //1ms,ish

    //example init from datasheet:
    transmitBuffer[0]=0x0fd; transferOK = SPI_transfer(masterSpi, &masterTransaction); //unlock cmds
/*    transmitBuffer[0]=0x112; transferOK = SPI_transfer(masterSpi, &masterTransaction); //turn it off

    transmitBuffer[0]=0x0ae; transferOK = SPI_transfer(masterSpi, &masterTransaction); //maybe

    transmitBuffer[0]=0x015; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x11c; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x15b; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x075; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x100; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x13f; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0bc; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x191; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0ca; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x13f; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0a2; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x100; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0a1; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x100; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0a0; transferOK = SPI_transfer(masterSpi, &masterTransaction);//remap: no idea
    transmitBuffer[0]=0x112; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x111; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0b5; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x100; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0ab; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x101; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0b4; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x1a0; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x1fd; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0c1; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x195; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0c7; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x1ef; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0b9; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0b1; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x1e2; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0d1; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x120; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x120; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0bb; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x11f; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0b6; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x108; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x1cd; transferOK = SPI_transfer(masterSpi, &masterTransaction);

    transmitBuffer[0]=0x0be; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    transmitBuffer[0]=0x107; transferOK = SPI_transfer(masterSpi, &masterTransaction);
*/
    transmitBuffer[0]=0x0a6; transferOK = SPI_transfer(masterSpi, &masterTransaction); //normal display, i think

    transmitBuffer[0]=0x0af; transferOK = SPI_transfer(masterSpi, &masterTransaction); //turn back on

    transmitBuffer[0]=0x0a5; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    __delay_cycles(70000000); //1s,ish
    transmitBuffer[0]=0x0a4; transferOK = SPI_transfer(masterSpi, &masterTransaction);
    __delay_cycles(70000000); //1s,ish

    transmitBuffer[0]=0x0a5; transferOK = SPI_transfer(masterSpi, &masterTransaction);

//    if(transferOK) {
        /* Print contents of master receive buffer */
//        System_printf("Master: %s\n", masterRxBuffer);
//    }
//    else {
//        System_printf("Unsuccessful master SPI transfer");
//    }


//    System_printf("transfer 2: ");
 //   System_flush();

    /* Deinitialize SPI */
    SPI_close(masterSpi);

    System_printf("Done\n");

    System_flush();
}
/*
 *  ======== main ========
 */
int main(void)
{
    /* Construct BIOS objects */
    Task_Params taskParams;

    /* Call board init functions. */
    Board_initGeneral();
    Board_initGPIO();
    Board_initSPI();
    Board_initADC();

    /* Construct master/slave Task threads */
    Task_Params_init(&taskParams);
    taskParams.priority = 2;
    taskParams.stackSize = TASKSTACKSIZE;
    taskParams.stack = &task0Stack;
    Task_construct(&task0Struct, (Task_FuncPtr)screenTaskFxn, &taskParams, NULL);

    // More important
    taskParams.stack = &task1Stack;
    taskParams.priority = 3;
    Task_construct(&task1Struct, (Task_FuncPtr)faderDataTaskFxn, &taskParams, NULL);

    /* Turn on user LED */
    GPIO_write(Board_LED2, Board_LED_ON); //0 is blue, 1 is green

    System_printf("here goes nothin!\n");
    /* SysMin will only print to the console when you call flush or exit */
    System_flush();

    /* Start BIOS */
    BIOS_start();

    return (0);
}
